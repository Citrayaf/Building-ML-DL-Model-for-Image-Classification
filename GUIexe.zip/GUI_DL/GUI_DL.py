import tkinter as tk
from tkinter import filedialog
from tkinter.filedialog import askopenfile
from PIL import Image, ImageTk
import pickle
import numpy as np
import cv2
from skimage.color import rgb2gray
from keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array, load_img
from tensorflow import expand_dims
import keras


my_w = tk.Tk()
my_w.geometry("625x500")  # Size of the window 
my_w.title('GUI')
my_font1=('times', 18, 'bold')

load = Image.open("saudia28.jpg")
render = ImageTk.PhotoImage(load)
img1 = tk.Label(my_w, image=render)
img1.image = render
img1.place(x=350, y=75)

load = Image.open("turkis39.jpg")
render = ImageTk.PhotoImage(load)
img2 = tk.Label(my_w, image=render)
img2.image = render
img2.place(x=150, y=75)

load = Image.open("IMG(18).jpg")
render = ImageTk.PhotoImage(load)
img3 = tk.Label(my_w, image=render)
img3.image = render
img3.place(x=250, y=195)

l2 = tk.Label(my_w,text='Klasifikasi Citra Kurma dengan metode Deep Learning',width=45,font=my_font1)  
l2.place(x=0, y=25)
l1 = tk.Label(my_w,text='Klasifikasikan Gambar',width=30,font=my_font1)  
l1.place(x=75, y=350)
b1 = tk.Button(my_w, text='Pilih Gambar', 
   width=20,command = lambda: open_img())
b1.pack()
b1.place(x=215, y=400)
C=""
class_dict = {0: 'Amirhajj', 1: 'Saudia', 2: 'Turkis'}
model = load_model('VGG.h5')

def openfilename():
    
    # open file dialog box to select image
    # The dialogue box has a title "Open"
    filename = filedialog.askopenfilename(title ='"pen')
    return filename

def open_img():
    # Select the Imagename  from a folder
    global model
    x = openfilename()
 
    # opens the image
    imga = Image.open(x)


    # class_dict = {0: 'Cat (Kucing)', 1: 'Dog (Anjing)'}

    gmbrz = np.array(imga.resize((224,224))) / 255.0
    # img_array = img_to_array(gmbrz) / 255.0
    img_array = expand_dims(gmbrz, 0)
    predict = model.predict(img_array)
    rounded_pred=np.argmax(predict, axis=1)
    rounded_pred=rounded_pred[0]

    hasil = class_dict[rounded_pred]
    print(rounded_pred)
    # # resize the image and apply a high-quality down sampling filter
    # img = imga.resize((250, 250), Image.ANTIALIAS)
 
    # # PhotoImage class is used to add image to widgets, icons etc
    # img = ImageTk.PhotoImage(img)
  
    # # create a label
    # panel = tk.Label(my_w, image = img)
     
    # # set the image as img
    # panel.image = img
    # panel.grid(row = 2)
    l3.config(text=hasil)

def image_to_feature_vector(image, size=(224, 224)):
	# resize the image to a fixed size, then flatten the image into
	# a list of raw pixel intensities
	return cv2.resize(image, size).flatten()

def extract_color_histogram(image, bins=(8, 8, 8)):

	hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
	hist = cv2.calcHist([hsv], [0, 1, 2], None, bins,
		[0, 180, 0, 256, 0, 256])
	if imutils.is_cv2():
		hist = cv2.normalize(hist)
	
	else:
		cv2.normalize(hist, hist)
	return hist.flatten()
    
l3 = tk.Label(my_w,text="",width=30,font=my_font1)  
l3.pack()
l3.place(x=70, y=435)

my_w.mainloop()  # Keep the window open